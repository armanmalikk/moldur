<?php
require('../functions.php');
?>

	<ul>
		<li> <a href="admin_comments.php">Admin Comment</a></li>
		<li> <a href="admin_orders.php">Admin Order</a></li>
		<li> <a href="admin_upload.php">Admin Upload</a></li>
		<li> <a href="admin_user.php">Admin User</a></li>
		<li> <a href="index.php">Home</a></li>
		<li> <a href="log_out.php">Log Out</a></li>
	</ul>

					<!------------------
				 start of Upload Full frame
					-------------------->

<?php 
if(isset($_POST['frame_submit'])){
	if(!empty($_POST['frame_tag_name']) && !empty($_POST['frame_price']) && !empty($_POST['frame_des']) && !empty($_FILES['frame_img']['tmp_name']) ){
		$image = $_FILES['frame_img']['tmp_name'];
		$image = file_get_contents($image);
		$image = base64_encode($image);
		$moldura->insert_into_table('INSERT INTO frames(frame_tag_name,frame_price,frame_des,frame_img)VALUES("'.$_POST["frame_tag_name"].'",
		"'.$_POST["frame_price"].'",
		"'.$_POST["frame_des"].'","'.$image.'")');
	}else{
		echo "</br>Can't keep fields blank";
	}	//end of if/else if all filled setted
}		//isset($_POST['frame_submit'])
?>

<h3>Upload Full frame</h3>

		<form method="POST" action="" enctype = "multipart/form-data">
			<label>Frame tag name</label></br>
			<input type="text" name="frame_tag_name" value=""/></br>
			<label>Frame price</label></br>
			<input type="text" name="frame_price" value=""/></br>
			<label>Frame description</label></br>
			<input type="text" name="frame_des" value=""/></br>
			<label>Frame image</label></br>
			<input type="file" name="frame_img" value=""/></br></br>
			<input type="submit" name="frame_submit"/>
		</form>
	
					   <!------------------
				    end of Upload Full frame
					    -------------------->
<hr>
					     <!------------------
				    	start of upload image
					    -------------------->
	<?php 
		if(isset($_POST['image_submit'])){
			if(!empty($_POST['image_tag_name']) && !empty($_POST['image_des']) && !empty($_FILES['image_img']['tmp_name']) ){
				$image = $_FILES['image_img']['tmp_name'];
				$image = file_get_contents($image);
				$image = base64_encode($image);
				$moldura->insert_into_table('INSERT INTO images(image_tag_name,image_des,image_img)VALUES(
				"'.$_POST["image_tag_name"].'","'.$_POST["image_des"].'","'.$image.'")'
				);
				echo $_FILES["image_img"]["size"];
			}else{
				echo "Can't keep fields blank";
			}	//end of if/else fields not empty
		}		// end of if image submit
	?>
<h3>Upload Image</h3>
	<form method="POST" action="" enctype = "multipart/form-data">
		<label>Image tag name</label><br>
		<input type="text" name="image_tag_name" value="" /><br>
		<label>Image description</label><br>
		<input type="text" name="image_des" value="" /><br>
		<label>image</label><br>
		<input type="file" name="image_img" value="" /><br></br>

		<input type="submit" name="image_submit"/>
	</form>
					   <!------------------
				    	end of Upload image
					    -------------------->
<hr>
						 <!------------------
					start of upload single fram
						-------------------->
	<?php 
		if(isset($_POST['sin_frame_submit'])){
			if(!empty($_POST['sin_frame_tag_name']) && !empty($_POST['sin_frame_price']) && !empty($_POST['sin_frame_des']) && !empty($_FILES['sin_frame_img']['tmp_name'])){
				$image = $_FILES['sin_frame_img']['tmp_name'];
				$image = file_get_contents($image);
				$image = base64_encode($image);

				$edge_image = $_FILES['sin_frame_edge_img']['tmp_name'];
				$edge_image = file_get_contents($edge_image);
				$edge_image = base64_encode($edge_image);

				$moldura->insert_into_table('INSERT INTO single_frames(single_frame_tag_name,single_frame_price,single_frame_des,single_frame_img,single_frame_edge_img)VALUES(
				"'.$_POST["sin_frame_tag_name"].'",
				"'.$_POST["sin_frame_price"].'",
				"'.$_POST["sin_frame_des"].'","'.$image.'","'.$edge_image.'")'
				);
			}else{
				echo "Can't keep fileds blank";
			}	// end of if/else for !empty fields
		}		//isset $_post['submit'];
	?>

<h3>Upload single frame</h3>
	<form method="POST" action="" enctype = "multipart/form-data">
		<label>Single Frame Tag Name</label><br>
		<input type="text" name="sin_frame_tag_name" value=""/><br>
		<label>Single Frame Price</label><br>
		<input type="text" name="sin_frame_price" value=""/><br>
		<label>Single Frame Description</label><br>
		<input type="text" name="sin_frame_des" value=""/><br>
		<label>Single Frame Image</label><br>
		<input type="file" name="sin_frame_img" value=""/><br></br>
		<label>Single Frame EDGE Image</label><br>
		<input type="file" name="sin_frame_edge_img" value="" required/><br></br>
		<input type="submit" name="sin_frame_submit"/>
	</form>
					 <!------------------
					end of upload single frame
						-------------------->

