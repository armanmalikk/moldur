<ul>
	<li> <a href="admin_comments.php">Admin Comment</a></li>
	<li> <a href="admin_orders.php">Admin Order</a></li>
	<li> <a href="admin_upload.php">Admin Upload</a></li>
	<li> <a href="admin_user.php">Admin User</a></li>
	<li> <a href="index.php">Home</a></li>
	<li> <a href="log_out.php">Log Out</a></li>
</ul>